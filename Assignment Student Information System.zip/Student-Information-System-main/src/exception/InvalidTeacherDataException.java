package exception;

public class InvalidTeacherDataException extends Exception {
    public InvalidTeacherDataException(String message) {
        super(message);
    }
}
