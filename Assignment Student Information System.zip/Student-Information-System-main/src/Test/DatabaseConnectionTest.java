package Test;
import model.*;

import java.sql.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class DatabaseConnectionTest {

    // Database connection details (replace with your actual database details)
    private static final String DB_URL = "jdbc:mysql://localhost:3308/SISDB"; // Example URL
    private static final String USER = "root"; // Your DB username
    private static final String PASSWORD = "12345678"; // Your DB password

    // JDBC connection object
    private static Connection connection = null;

    // Method to initialize the database connection and create necessary tables
    public static void initializeDatabase() {
        try {
            // Step 1: Establish a connection to the database
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Database connection established.");

            // Step 2: Create tables (if they don't already exist)
            createTables();

        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to create tables if they don't exist
    private static void createTables() {
        try {
            Statement statement = connection.createStatement();

            // Create Students table
            String createStudentsTable = "CREATE TABLE IF NOT EXISTS students ("
                    + "student_id INT PRIMARY KEY, "
                    + "first_name VARCHAR(50), "
                    + "last_name VARCHAR(50), "
                    + "date_of_birth DATE, "
                    + "email VARCHAR(100), "
                    + "phone_number VARCHAR(15))";
            statement.executeUpdate(createStudentsTable);
            System.out.println("Students table created.");

            // Create Courses table
            String createCoursesTable = "CREATE TABLE IF NOT EXISTS courses ("
                    + "course_id INT PRIMARY KEY, "
                    + "course_name VARCHAR(100), "
                    + "course_code VARCHAR(10), "
                    + "instructor_name VARCHAR(100))";
            statement.executeUpdate(createCoursesTable);
            System.out.println("Courses table created.");

            // Create Enrollments table
            String createEnrollmentsTable = "CREATE TABLE IF NOT EXISTS enrollments ("
                    + "enrollment_id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "student_id INT, "
                    + "course_id INT, "
                    + "enrollment_date DATE, "
                    + "FOREIGN KEY (student_id) REFERENCES students(student_id), "
                    + "FOREIGN KEY (course_id) REFERENCES courses(course_id))";
            statement.executeUpdate(createEnrollmentsTable);
            System.out.println("Enrollments table created.");

        } catch (SQLException e) {
            System.err.println("Error creating tables: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to fetch all students
    public static List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        try {
            String query = "SELECT * FROM students";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Process the result set and populate the student list
            while (resultSet.next()) {
                int studentId = resultSet.getInt("student_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                Date dateOfBirth = resultSet.getDate("date_of_birth");
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");

                Student student = new Student(studentId, firstName, lastName, dateOfBirth, email, phoneNumber);
                students.add(student);
            }

        } catch (SQLException e) {
            System.err.println("Error retrieving students: " + e.getMessage());
            e.printStackTrace();
        }

        return students;
    }

    // Method to fetch students by a specific condition (SQL WHERE clause)
    public static List<Student> getStudentsByCondition(String condition) {
        List<Student> students = new ArrayList<>();
        try {
            String query = "SELECT * FROM students WHERE " + condition;
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);

            // Process the result set and populate the student list
            while (resultSet.next()) {
                int studentId = resultSet.getInt("student_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                Date dateOfBirth = resultSet.getDate("date_of_birth");
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");

                Student student = new Student(studentId, firstName, lastName, dateOfBirth, email, phoneNumber);
                students.add(student);
            }

        } catch (SQLException e) {
            System.err.println("Error retrieving students by condition: " + e.getMessage());
            e.printStackTrace();
        }

        return students;
    }

    // Insert a student into the database (replace with actual DB logic)
    public static void insertStudent(Student student) {
        try {
            String query = "INSERT INTO students (student_id, first_name, last_name, date_of_birth, email, phone_number) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, student.getStudentId());
            preparedStatement.setString(2, student.getFirstName());
            preparedStatement.setString(3, student.getLastName());
            preparedStatement.setDate(4, student.getDateOfBirth());
            preparedStatement.setString(5, student.getEmail());
            preparedStatement.setString(6, student.getPhoneNumber());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error inserting student: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Close the database connection (good practice)
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
