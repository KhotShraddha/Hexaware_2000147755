package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {

    private static Connection connection;

    // Initialize the database connection
    public static void initializeDatabase() {
        try {
            String url = "jdbc:mysql://localhost:3308/SISDB";
            String username = "root";
            String password = "12345678";
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connected successfully!");
        } catch (SQLException e) {
            System.err.println("Database connection failed: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Insert a student into the database
    public static void insertStudent(Student student) {
        String query = "INSERT INTO students (student_id, first_name, last_name, date_of_birth, email, phone_number) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, student.getStudentId());
            statement.setString(2, student.getFirstName());
            statement.setString(3, student.getLastName());
            statement.setDate(4, student.getDateOfBirth());
            statement.setString(5, student.getEmail());
            statement.setString(6, student.getPhoneNumber());
            statement.executeUpdate();
            System.out.println("Student added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding student: " + e.getMessage());
        }
    }

    // Get all students from the database
    public static List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String query = "SELECT * FROM students";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int studentId = resultSet.getInt("student_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                Date dateOfBirth = resultSet.getDate("date_of_birth");
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");
                students.add(new Student(studentId, firstName, lastName, dateOfBirth, email, phoneNumber));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving students: " + e.getMessage());
        }
        return students;
    }

    // Get student by ID from the database
    public static Student getStudentById(int studentId) {
        Student student = null;
        String query = "SELECT * FROM students WHERE student_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, studentId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String firstName = resultSet.getString("first_name");
                    String lastName = resultSet.getString("last_name");
                    Date dateOfBirth = resultSet.getDate("date_of_birth");
                    String email = resultSet.getString("email");
                    String phoneNumber = resultSet.getString("phone_number");
                    student = new Student(studentId, firstName, lastName, dateOfBirth, email, phoneNumber);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving student: " + e.getMessage());
        }
        return student;
    }

    // Get course by ID from the database
    public static Course getCourseById(int courseId) {
        Course course = null;
        String query = "SELECT * FROM courses WHERE course_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, courseId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String courseName = resultSet.getString("course_name");
                    String description = resultSet.getString("description");
                    try {
                        course = new Course(courseId, courseName, description);
                    } catch (InvalidCourseDataException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving course: " + e.getMessage());
        }
        return course;
    }

    // Insert an enrollment into the database
    public static void insertEnrollment(Enrollment enrollment) {
        String query = "INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, enrollment.getStudent().getStudentId());
            statement.setInt(2, enrollment.getCourse().getCourseId());
            statement.setDate(3, enrollment.getEnrollmentDate());
            statement.executeUpdate();
            System.out.println("Enrollment added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding enrollment: " + e.getMessage());
        }
    }

    // Get students by condition (e.g., course_id)
    public static List<Student> getStudentsByCondition(String condition) {
        List<Student> students = new ArrayList<>();
        String query = "SELECT s.* FROM students s JOIN enrollments e ON s.student_id = e.student_id WHERE " + condition;
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int studentId = resultSet.getInt("student_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                Date dateOfBirth = resultSet.getDate("date_of_birth");
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");
                students.add(new Student(studentId, firstName, lastName, dateOfBirth, email, phoneNumber));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving students by condition: " + e.getMessage());
        }
        return students;
    }

    // Get the database connection
    public static Connection getConnection() {
        // Check if the connection has already been initialized
        if (connection == null) {
            System.err.println("Database connection is not initialized!");
            return null;
        }
        return connection;
    }
}
